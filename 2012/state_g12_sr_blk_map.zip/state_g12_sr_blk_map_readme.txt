Filename:	state_g12_sr_blk_map.dbf, state_g12_sr_blk_map.csv

File URL:	http://http://statewidedatabase.org/pub/data/G12/state/state_g12_sr_blk_map.zip

Dataset:	2012 General Election precinct geographic conversion file

Description:	This file contains a statewide 2010 Census block conversion file for the 2012 General Election SR precincts. 

Geographic Unit:	SR precincts are derived from consolidated precincts and are a geographic unit constructed for statistical merging purposes by the Statewide Database.  

Please refer to the technical documentation: http://http://statewidedatabase.org//d10/Creating%20CA%20Official%20Redistricting%20Database.pdf


File Fields:


	ELECTION - 3 digit, election abbreviation

	TYPE - geographic unit of analysis 

	COUNTY - 3 digit county number

	FIPS - 2 digit state code FIPS for California, "06," followed by the 3 digit county FIPS code 

	SRPREC_KEY - FIPS code followed by the precinct number or name

	SRPREC - precinct number or name

	BLOCK_KEY - 15 digit 2010 Census Block code 

	TRACT -	6 digit 2010 Census Tract code 

	BLOCK - 2010 Census Block Code

	BLKREG - Total registered voters geocoded to the intersecting portion of the census block and precinct

	SRTOTREG - Total registered voters geocoded to the precinct

	PCTSRPREC - Percent of the precinct's total registered voters that geocoded to the intersecting portion of the census block and precinct

	BLKTOTREG - Toal registered voters geocoded to the 2010 Census block

	PCTBLK - Percent of the Census block's total registered voters geocoded to the intersecting portion of the census block and precinct


Date last modified:	11/19/2018

Previous Versions:	10/10/2017;	10/14/2016;	07/27/2015;	04/14/2014;	03/13/2014

County records not available or unavailable at time of file creation: none



