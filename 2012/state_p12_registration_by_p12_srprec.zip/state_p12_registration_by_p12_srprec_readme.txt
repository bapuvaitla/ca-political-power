Filename:	state_p12_registration_by_p12_srprec.zip

File URL:	http://statewidedatabase.org/pub/data/P12/state/state_p12_registration_by_p12_srprec.zip

Dataset:	2012 Primary Election Precinct Data

Description:	This file contains statewide registration data for all registered voters. 

Unit of analysis: SR precincts are derived from consolidated precincts and are a geographic unit constructed for statistical merging purposes by the Statewide Database.

Data source:	Statewide Database - University of California, Berkeley

Technical documentation:	http://statewidedatabase.org/d10/Creating%20CA%20Official%20Redistricting%20Database.pdf

Codebook:	http://statewidedatabase.org/info/metadata/SOR_codebook.html


Date last modified:	Wed, 28 Jan 2015

Previous versions:	Thu, 05 Jun 2014; Fri, 14 Feb 2014 11:19:03 -0800

County records unavailable at time of file creation:	none

Errata 1:	There are discrepancies in totals in the rg, rr and sr precinct files for the following counties
037 - Los Angeles rg file has 2,828 more registered voters than the rr and sr files
049 - Modoc rg file has 1 more registered voter than the rr and sr files
053 - Monterey rg file has 15 more registered voters than the rr and sr files
067 - Sacramento rg file has 1 more registered voter than the rr and sr files
069 - San Benito rg file has 1 more registered voter than the rr and sr files
071 - San Bernardino rg file has 1 more registered voter than the rr and sr files
075 - San Francisco rg file has 1 more registered voter than the rr and sr files
095 - Solano rg file has 657 more registered voters than the rr and sr files        
099 - Stanislaus rg file has 604 more registered voters than the rr and sr files
107 - Tulare rg file has 8 more registered voters than the rr and sr files

