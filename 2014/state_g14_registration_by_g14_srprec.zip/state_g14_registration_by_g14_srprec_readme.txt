Filename:	state_g14_registration_by_g14_srprec.dbf, state_g14_registration_by_g14_srprec.csv

File URL:	http://statewidedatabase.org/pub/data/G14/state/state_g14_registration_by_g14_srprec.zip

Dataset:	2014 General Election Precinct Data

Description:	This file contains statewide registration data for all registered voters. 

Unit of analysis:	SR precincts are derived from consolidated precincts and are a geographic unit constructed for statistical merging purposes by the Statewide Database.

Data source:	Statewide Database - University of California, Berkeley

Technical documentation:	http://statewidedatabase.org/d10/Creating%20CA%20Official%20Redistricting%20Database.pdf

Codebook:	http://statewidedatabase.org/info/metadata/SOR_codebook.html

Date last modified:	Fri, 21 Sep 2018  

Previous versions:	Sat, 20 Jun 2015 ;	Wed, 10 Jun 2015;	Tue, 28 Apr 2015  

County records unavailable at time of file creation:	none

Errata 1:	There are discrepancies in totals in the rg, rr and sr precinct files for the following counties
001 - Alameda rg file has 1 more registered voter than the rr and sr files
037 - Los Angeles rg file has 923 more registered voters than the rr and sr files
073 - San Diego rg file has 1 more registered voter than the rr and sr files
075 - San Francisco rg file has 1 more registered voter than the rr and sr files

Errata 2:

Fri, 21 Sep 2018 records in the file were updated for the following counties: c057 - Nevada and c083 - Santa Barbara.

The current, Fri, 21 Sep 2018 statewide version of this file has 4 more records than the 2015 version. Total registered voters are the same in both files. There are 2 additional sr precinct records in the c057 -Nevada file and 2 additional sr precincts in the c083 - Santa Barbara file.

The 2018 statewide version of c057 - Nevada file has 60 total records while the 2015 version has 58 total records. The 2018 version has 3 sr precincts: "MB65", totreg_r=139, "MB68", totreg_r=86, and "MB69", totreg_r=121 that are not present in the 2015 version.  The 2015 version has 1 sr precinct, "MB53" with totreg_r=346 that is not in the 2018 version that accounts for the registered voters that were allocated to the 3 sr precincts in the 2018 versions.

The 2018 statewide version of c083 - Santa Barbara file has 202 total records while the 2015 version has only 200 total records. The 2018 statewide version of the file has 2 sr precincts, sr precinct "30-3029" with totreg_r = 385 & sr precinct "40-4029" with totreg_r=209 that are not present in the 2015 version file. The 385 & 209 registered voters that are respectively contained in the above precincts were reported in sr precinct "30-3028" with totreg_r=478 and in sr precinct "40-4028" with totreg_r=512 in the 2015 version of the file. In the 2018 version of the file, precincts "30-3028" and "40-4028" have a totreg_r=385 and totreg_r=209, respectively.
