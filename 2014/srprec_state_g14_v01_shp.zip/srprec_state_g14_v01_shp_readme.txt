Filename:	srprec_state_g14_v01_shp.zip

File URL:	http://statewidedatabase.org/pub/data/G14/state/srprec_state_g14_v01_shp.zip

Dataset:	2014 General Election precinct boundary GIS file

Description:	This file contains statewide precinct boundary file for the map precincts. 

Geographic Unit:	SR precincts are derived from consolidated precincts and are a geographic unit constructed for statistical merging purposes by the Statewide Database.  

Technical documentation: http://statewidedatabase.org/d10/Creating%20CA%20Official%20Redistricting%20Database.pdf

File Fields:

	AREA - area of the precinct in square miles

	ELECTION - 3 digit, election abbreviation

	TYPE - geographic unit

	COUNTY - 3 digit county number

	FIPS - 2 digit state code FIPS for California, "06," followed by the 3 digit county FIPS code 

	SRPREC_KEY - FIPS code followed by the precinct number or name

	SRPREC - SR precinct number or name

User Notes:	The SR precinct boundary file is in .shp file format. The .shp file is compatible with any ArcGIS program by ESRI. Many open source and low cost GIS platforms are able to view and open the .shp file type.

Date last modified:	06/24/2015

Previous Versions:	06/03/2015;	05/27/2015

County records not available or unavailable at time of file creation:	none