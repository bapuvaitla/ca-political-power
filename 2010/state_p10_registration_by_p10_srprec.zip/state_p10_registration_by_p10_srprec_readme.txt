Filename: state_p10_registration_by_p10_srprec.zip, state_p10_registration_by_p10_srprec.dbf

File URL: http://swdb.berkeley.edu/pub/data/P10/state/state_p10_registration_by_p10_srprec.zip

Dataset: 2010 Primary Election Precinct Data

Description:  This file contains statewide registration data for all registered voters. SR precincts are derived from Consolidated Precincts (geographic unit constructed for statistical merging purposes by SWDB)

Please refer to technical documentation for further information,
http://swdb.berkeley.edu/d10/Creating%20CA%20Official%20Redistricting%20Database.pdf

Variable codebook,
http://swdb.berkeley.edu/info/metadata/SOR_codebook.html 

Date last modified: 11/02/2012, Previous Versions Modified:  10/22/2012, 3/4/2011

County records not available or unavailable at time of file creation: 

06015 - DEL NORTE