Filename: state_p10_sov_data_by_p10_srprec.zip

File URL: http://statewidedatabase.org/pub/data/P10/state/state_p10_sov_data_by_p10_srprec.zip

Dataset: 2010 Primary Election Precinct Data

Description: This file contains statewide precinct level voting results. SR precincts are derived from Consolidated Precincts (geographic unit constructed for statistical merging purposes by SWDB)
Please refer to technical documentation for further information,
http://statewidedatabase.org/d10/Creating%20CA%20Official%20Redistricting%20Database.pdf

Variable codebook,
http://statewidedatabase.org/info/metadata/SOR_codebook.html 

Date last modified: 2/26/2013, the file was modified to remove the 996 sv precinct records that were present in previous version of the file. The 996 sv precincts records were merged into 
their sr precincts of origin.

County records not available or unavailable at time of file creation: none

